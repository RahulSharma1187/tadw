$(".btn-csv").click(function(e) {
	console.log("CSV export");
	/*$("#issuerTable").table2excel({
		// exclude CSS class
		exclude : ".noExl",
		name : "Worksheet Name",
		filename : "Foreign_Ownership", // do not include extension111
		fileext : ".csv" // file extension
	});*/
	
	// following code is copied from derivativesMarketWatch.jsp, above code was not working
	$("#issuerTable").tableHTMLExport({
	      type:'csv',
	      filename:'Today-Market-Watch.csv',
	});
});

$(".btn-pdf").click(function(e) {
	console.log("pdf export");
	html2canvas($('#issuerTable')[0], {
		onrendered : function(canvas) {
			var data = canvas.toDataURL();
			var docDefinition = {
				content : [ {
					image : data,
					width : 500
				} ]
			};
			pdfMake.createPdf(docDefinition).download("Foreign_Ownership.pdf");
		}
	});
});